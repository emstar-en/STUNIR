#!/usr/bin/env bash
set -e

STUNIR_BIN=build/stunir_native
SHELL_COMPILER=scripts/compile.sh
SPEC=build/human_spec.json
IR=build/pipeline.ir.json
OUT_DIR=build/dist

mkdir -p "$OUT_DIR"

echo "=== STUNIR Build Pipeline ==="

if [ ! -f "$STUNIR_BIN" ]; then
  echo "[ERROR] Missing native binary: $STUNIR_BIN"
  echo "Build it first (example):"
  echo "  cd tools/native/rust/stunir-native && cargo build --release"
  echo "  cp target/release/stunir-native build/stunir_native"
  exit 2
fi

if [ ! -f "$SPEC" ]; then
  echo "[ERROR] Missing spec: $SPEC"
  echo "Create it (or point SPEC to the right file)"
  exit 2
fi

echo "[1/2] Compiling with Native Binary..."
"$STUNIR_BIN" compile --in-spec "$SPEC" --out-ir "$IR"

# Emit step: prefer python, but fall back to bash if native core doesn't support python yet.
TARGET="${STUNIR_TARGET:-python}"

emit_python() {
  "$STUNIR_BIN" emit --in-ir "$IR" --target python --out-file "$OUT_DIR/app.py"
}

emit_bash() {
  "$STUNIR_BIN" emit --in-ir "$IR" --target bash --out-file "$OUT_DIR/app.sh"
  chmod +x "$OUT_DIR/app.sh" || true
}

echo "[2/2] Emitting Code (Polyglot)..."
if [ "$TARGET" = "python" ]; then
  set +e
  emit_python
  rc=$?
  set -e

  if [ $rc -ne 0 ]; then
    echo "[WARN] Native emitter rejected --target python; falling back to bash."
    emit_bash
  fi
elif [ "$TARGET" = "bash" ]; then
  emit_bash
else
  echo "[ERROR] Unsupported STUNIR_TARGET=$TARGET (expected python or bash)"
  exit 2
fi

echo "[OK] Outputs in: $OUT_DIR"
ls -la "$OUT_DIR" || true
