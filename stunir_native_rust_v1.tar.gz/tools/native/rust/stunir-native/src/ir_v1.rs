use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct IrV1 {
    pub functions: Vec<Function>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Function {
    pub name: String,
    pub body: Vec<Instruction>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Instruction {
    pub op: String,
    pub args: Vec<String>,
}
