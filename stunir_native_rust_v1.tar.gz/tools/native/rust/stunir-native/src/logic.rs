use crate::ir_v1::{IrV1, Function, Instruction};
use anyhow::Result;

pub fn spec_to_ir(_spec: &str) -> Result<IrV1> {
    let main_body = vec![
        Instruction {
            op: "print".to_string(),
            args: vec!["Hello from STUNIR!".to_string()],
        }
    ];
    Ok(IrV1 {
        functions: vec![
            Function { name: "main".to_string(), body: main_body }
        ]
    })
}
