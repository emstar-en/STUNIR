use crate::errors::StunirError;
use crate::ir_v1::IrV1;
use anyhow::Result;
use std::fs;

mod python;

pub fn run(in_ir: &str, target: &str, out_file: &str) -> Result<()> {
    let content = fs::read_to_string(in_ir).map_err(|e| StunirError::Io(e.to_string()))?;
    let ir: IrV1 = serde_json::from_str(&content).map_err(|e| StunirError::Json(e.to_string()))?;

    match target {
        "python" => python::emit(&ir, out_file),
        _ => Err(StunirError::Usage(format!("Target {} not supported yet", target)).into()),
    }
}
