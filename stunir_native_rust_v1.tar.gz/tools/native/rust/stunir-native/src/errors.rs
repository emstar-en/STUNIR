use thiserror::Error;

#[derive(Error, Debug)]
pub enum StunirError {
    #[error("IO Error: {0}")]
    Io(String),
    #[error("JSON Error: {0}")]
    Json(String),
    #[error("Usage Error: {0}")]
    Usage(String),
}
