mod ir_v1;
mod logic;
mod emit;
mod errors;

use clap::{Parser, Subcommand};
use anyhow::Result;

#[derive(Parser)]
#[command(name = "stunir-native")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    SpecToIr {
        #[arg(long)] in_json: String,
        #[arg(long)] out_ir: String,
    },
    Emit {
        #[arg(long)] in_ir: String,
        #[arg(long)] target: String,
        #[arg(long)] out_file: String,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::SpecToIr { in_json, out_ir } => {
            let ir = logic::spec_to_ir(&in_json)?;
            let ir_json = serde_json::to_string_pretty(&ir)?;
            if let Some(parent) = std::path::Path::new(&out_ir).parent() {
                std::fs::create_dir_all(parent)?;
            }
            std::fs::write(out_ir, ir_json)?;
            Ok(())
        }
        Commands::Emit { in_ir, target, out_file } => {
            emit::run(&in_ir, &target, &out_file)
        }
    }
}
